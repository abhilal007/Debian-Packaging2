warn "Capistrano notifier has been extracted to `capistrano-flowdock` gem"
